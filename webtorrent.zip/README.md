# webtorrent-demo

[JSBox Node.js](https://cyanzhong.github.io/jsbox-nodejs/#/en/) example that shows you:

- How to use 3rd-party node modules like `webtorrent`
- How to handle input & output
- How to use native modules like `input`, `clipboard`

# Instructions

- Install [JSBox](https://apps.apple.com/us/app/id1312014438) 2.0
- Run `npm install` to resolve dependencies